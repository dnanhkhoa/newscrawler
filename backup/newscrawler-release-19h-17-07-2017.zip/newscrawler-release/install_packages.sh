#!/bin/bash
sudo apt-get install --upgrade -y python3-pip python3-dev python-imaging libjpeg8 libjpeg62-dev libfreetype6 libfreetype6-dev
sudo pip3 install --upgrade setuptools regex dateparser requests cchardet beautifulsoup4 html5lib pafy bleach pymysql Pillow