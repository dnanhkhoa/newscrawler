#!/bin/bash
rm -rf log
rm -rf check_log
